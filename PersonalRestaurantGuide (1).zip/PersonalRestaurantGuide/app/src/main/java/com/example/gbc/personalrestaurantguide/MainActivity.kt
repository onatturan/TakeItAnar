package com.example.gbc.personalrestaurantguide

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.gbc.personalrestaurantguide.ui.theme.PersonalRestaurantGuideTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            PersonalRestaurantGuideTheme {
                val navController = rememberNavController()
                MainNavHost(navController)
            }
        }
    }
}

@Composable
fun MainNavHost(navController: NavHostController) {
    NavHost(navController = navController, startDestination = "main") {
        composable("main") { MainScreen(navController) }
        composable("addRestaurant") { AddRestaurantScreen(navController) }
        composable("viewRestaurants") { ViewRestaurantsScreen() }
    }
}

@Composable
fun MainScreen(navController: NavHostController) {
    Scaffold(
        topBar = {
            TopAppBar(title = { Text("Personal Restaurant Guide") })
        },
        content = { padding ->
            Column(
                modifier = Modifier
                    .padding(padding)
                    .padding(16.dp)
                    .fillMaxSize(),
                verticalArrangement = Arrangement.Center
            ) {
                Button(
                    onClick = { navController.navigate("addRestaurant") },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Add Restaurant")
                }
                Spacer(modifier = Modifier.height(16.dp))
                Button(
                    onClick = { navController.navigate("viewRestaurants") },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("View Restaurants")
                }
            }
        }
    )
}

@Composable
fun AddRestaurantScreen(navController: NavHostController) {
    var restaurantName by remember { mutableStateOf("") }
    var restaurantAddress by remember { mutableStateOf("") }

    Scaffold(
        topBar = {
            TopAppBar(title = { Text("Add Restaurant") })
        },
        content = { padding ->
            Column(
                modifier = Modifier
                    .padding(padding)
                    .padding(16.dp)
                    .fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text(text = "Enter Restaurant Details", style = MaterialTheme.typography.titleMedium)
                TextField(
                    value = restaurantName,
                    onValueChange = { restaurantName = it },
                    label = { Text("Restaurant Name") },
                    modifier = Modifier.fillMaxWidth()
                )
                TextField(
                    value = restaurantAddress,
                    onValueChange = { restaurantAddress = it },
                    label = { Text("Restaurant Address") },
                    modifier = Modifier.fillMaxWidth()
                )
                Button(
                    onClick = {
                        // Save functionality placeholder.
                        navController.navigate("viewRestaurants")
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Save Restaurant")
                }
            }
        }
    )
}

@Composable
fun ViewRestaurantsScreen() {
    val sampleRestaurants = listOf(
        "Restaurant A - 123 Main St",
        "Restaurant B - 456 Elm St",
        "Restaurant C - 789 Oak St"
    )

    Scaffold(
        topBar = {
            TopAppBar(title = { Text("View Restaurants") })
        },
        content = { padding ->
            Column(
                modifier = Modifier
                    .padding(padding)
                    .padding(16.dp)
                    .fillMaxSize()
            ) {
                Text(text = "Saved Restaurants", style = MaterialTheme.typography.titleMedium)
                Spacer(modifier = Modifier.height(16.dp))
                sampleRestaurants.forEach { restaurant ->
                    Text(
                        text = restaurant,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp)
                    )
                }
            }
        }
    )
}
