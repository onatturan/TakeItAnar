package com.example.gbc.personalrestaurantguide.ui.theme

import androidx.compose.material3.Typography

// Material 3 Typography tanımı
val CustomTypography = Typography()
